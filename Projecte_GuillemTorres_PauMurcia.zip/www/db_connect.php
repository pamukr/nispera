<?php
$servername = "mysql";
$username = "nispera_admin";
$password = "33qysqlsqsdemctqvclbqatmESTOPA";
$database = "nispera";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $database);